package de.deltatree.social.web.filter.api.security;

public class SASFSecurityException extends Exception {
	private static final long serialVersionUID = 1L;

	public SASFSecurityException(Throwable cause) {
		super(cause);
	}
}
