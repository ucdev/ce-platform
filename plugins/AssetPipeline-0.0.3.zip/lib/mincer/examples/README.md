Mincer Examples
===============

Examples of Mincer usage.

- `server.js`:    Example of using Mincer's server for serving assets
- `manifest.js`:  Example of useng Mincer's manifest compiler

You will need install some additional modules in order to run these examples:

    npm install connect less ejs uglify-js csso jade haml-coffee


Assets middleware server demo
-----------------------------

Run:

    node ./server.js


Precompiling assets (Manifest usage)
------------------------------------

Run:

    node ./manifest.js
