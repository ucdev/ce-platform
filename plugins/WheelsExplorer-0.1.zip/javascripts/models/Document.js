var Doctor = Backbone.Model.extend({

});


